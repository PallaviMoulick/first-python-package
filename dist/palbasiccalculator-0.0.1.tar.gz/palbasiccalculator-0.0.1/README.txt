This is a personal project to test out creating packages in python. Inspiration taken from Joshua Lowe.

This is a very simple calculator which takes two numbers and performs these four operations : Add, Subtract, Multiply and Divice